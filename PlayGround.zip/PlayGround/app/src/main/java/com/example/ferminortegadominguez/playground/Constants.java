package com.example.ferminortegadominguez.playground;



public class Constants {

    //youtube developer API Key
    public static String DEVELOPER_KEY = "AIzaSyCGXVqnb3e9rXF6521cKDVDbsGVzGJHVuE";
}
